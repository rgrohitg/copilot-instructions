# Migration Documentation Kit

A structured toolkit for documenting a .NET monolith before migrating to 
React + Java Spring Boot + Databricks.

**Philosophy: Document everything first. Migrate nothing until the docs exist.**

---

## What's in this kit

```
.github/
├── copilot-instructions.md        ← DROP THIS INTO YOUR REPO ROOT
└── prompts/
    ├── 01-scan-feature.prompt.md          ← Document one controller/feature
    ├── 02-document-stored-proc.prompt.md  ← Document one stored procedure
    ├── 03-risk-scan.prompt.md             ← Risk-only scan of any file
    ├── 04-migrate-controller.prompt.md    ← Generate Java from doc card
    ├── 05-solution-overview.prompt.md     ← One-time full project overview
    ├── 06-controller-inventory.prompt.md  ← List all controllers + routes
    ├── 07-dependency-scan.prompt.md       ← All external integrations
    └── 08-unknown-unknowns.prompt.md      ← What you don't know you don't know

scripts/
├── 01-scan-codebase.sh                    ← Run from solution root — saves all output to docs/
└── sql/
    └── sql-metadata-extraction.sql        ← Run in SSMS — save results as CSV

docs/
└── migration/                             ← All documentation output goes here
    ├── features/                          ← One .md per feature
    └── stored-procs/                      ← One .md per stored procedure
```

---

## Step-by-step: How to use this

### Step 1 — Drop into your repo (5 minutes)

Copy `.github/` folder into your .NET solution root.
Edit `copilot-instructions.md` — fill in the [FILL IN] placeholders.

### Step 2 — Run the codebase scan (10-15 minutes)

```bash
# From your .NET solution root
chmod +x scripts/01-scan-codebase.sh
bash scripts/01-scan-codebase.sh
```

This saves 9 markdown files to `docs/migration/` automatically.
No copy-pasting needed.

### Step 3 — Run the SQL queries (30-60 minutes)

Open SQL Server Management Studio.
Open `scripts/sql/sql-metadata-extraction.sql`
Run each numbered query separately.
Save each result as CSV to `docs/migration/02j-database-inventory/`
Name the files to match the comment at the top of each query.

### Step 4 — Run Copilot prompts in order

Open VS Code with GitHub Copilot enabled.

**Run these ONCE (whole project):**
1. Open Copilot Chat → run `05-solution-overview.prompt.md`
   → Save output to `docs/migration/01-project-overview.md`

2. Run `06-controller-inventory.prompt.md`
   → Save output to `docs/migration/02b-controllers.md`

3. Run `07-dependency-scan.prompt.md`
   → Save output to `docs/migration/03-dependency-map.md`

**Run these PER CONTROLLER:**
4. Open a controller file
5. Run `01-scan-feature.prompt.md` → Save to `docs/migration/features/[name].md`
6. Run `03-risk-scan.prompt.md` → Append to `docs/migration/04-risk-register.md`

**Run this PER STORED PROCEDURE:**
7. Copy stored proc SQL from SSMS
8. Paste into Copilot Chat with `02-document-stored-proc.prompt.md`
9. Save to `docs/migration/stored-procs/[name].md`

**Run this LAST:**
10. Run `08-unknown-unknowns.prompt.md`
    → Save to `docs/migration/04-risk-register.md` (append to bottom)

### Step 5 — Start migrating (only after docs are complete)

For each feature, in risk order (low risk first):
1. Confirm Feature Documentation Card exists
2. Confirm all stored proc docs exist for that feature
3. Run `04-migrate-controller.prompt.md` with the doc as input

---

## Tips to avoid Copilot timeouts

- Never ask Copilot to "scan the whole project" in one go
- Always paste stored procedures directly — don't reference .sql files
- Work one controller at a time for deep scans
- Use `@workspace` only for the one-time overview prompts
- If Copilot seems to lose context mid-response, break the prompt into smaller pieces

---

## Output folder structure (what you'll end up with)

```
docs/migration/
├── 00-scan-index.md
├── 01-project-overview.md
├── 02a-folder-structure.md
├── 02b-controllers.md
├── 02c-services.md
├── 02d-data-access.md
├── 02e-stored-proc-callsites.md
├── 02f-external-calls.md
├── 02g-config-references.md
├── 02h-nuget-packages.md
├── 02i-risk-patterns.md
├── 02j-database-inventory/
│   ├── 01-table-inventory.csv
│   ├── 02-column-definitions.csv
│   ├── 03-stored-proc-inventory.csv
│   ├── 04-stored-proc-definitions.csv
│   ├── 05-cross-schema-fkeys.csv
│   ├── 06-proc-table-dependencies.csv
│   ├── 07-standalone-tables.csv
│   ├── 08-views.csv
│   ├── 09-most-coupled-tables.csv
│   └── 10-indexes.csv
├── 03-dependency-map.md
├── 04-risk-register.md
├── features/
│   ├── [FeatureName].md     ← one per controller
│   └── ...
└── stored-procs/
    ├── [ProcName].md        ← one per stored proc
    └── ...
```
