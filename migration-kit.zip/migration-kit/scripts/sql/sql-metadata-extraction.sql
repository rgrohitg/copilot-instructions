-- ============================================================
-- sql-metadata-extraction.sql
-- Run each section in SQL Server Management Studio
-- Save each result set as CSV to docs/migration/02j-database-inventory/
--
-- ⚙️  CONFIGURE HERE BEFORE RUNNING
-- Replace the database name below with your actual database name.
-- All queries will be scoped to ONLY that database.
-- If you have multiple databases to scan, run the whole script
-- again after changing this value.
-- ============================================================

USE [YOUR_DATABASE_NAME_HERE];   -- ← CHANGE THIS. Only thing you need to edit.
GO

-- ============================================================
-- QUERY 1: Full table inventory (scoped to this database only)
-- Save as: 01-table-inventory.csv
-- ============================================================
SELECT
    DB_NAME()                   AS Database_Name,
    t.TABLE_SCHEMA,
    t.TABLE_NAME,
    t.TABLE_TYPE,
    COUNT(c.COLUMN_NAME)        AS Column_Count
FROM INFORMATION_SCHEMA.TABLES t
JOIN INFORMATION_SCHEMA.COLUMNS c
    ON  t.TABLE_NAME   = c.TABLE_NAME
    AND t.TABLE_SCHEMA = c.TABLE_SCHEMA
WHERE t.TABLE_TYPE = 'BASE TABLE'
GROUP BY t.TABLE_SCHEMA, t.TABLE_NAME, t.TABLE_TYPE
ORDER BY t.TABLE_SCHEMA, t.TABLE_NAME;

-- ============================================================
-- QUERY 2: Full column definitions — your data dictionary
-- Save as: 02-column-definitions.csv
-- ============================================================
SELECT
    DB_NAME()                   AS Database_Name,
    TABLE_SCHEMA,
    TABLE_NAME,
    COLUMN_NAME,
    ORDINAL_POSITION,
    DATA_TYPE,
    CHARACTER_MAXIMUM_LENGTH,
    NUMERIC_PRECISION,
    NUMERIC_SCALE,
    IS_NULLABLE,
    COLUMN_DEFAULT
FROM INFORMATION_SCHEMA.COLUMNS
ORDER BY TABLE_SCHEMA, TABLE_NAME, ORDINAL_POSITION;

-- ============================================================
-- QUERY 3: Stored procedure inventory with size + dates
-- Save as: 03-stored-proc-inventory.csv
-- ============================================================
SELECT
    DB_NAME()                          AS Database_Name,
    ROUTINE_SCHEMA,
    ROUTINE_NAME,
    LEN(ROUTINE_DEFINITION)            AS Char_Length,
    CREATED,
    LAST_ALTERED
FROM INFORMATION_SCHEMA.ROUTINES
WHERE ROUTINE_TYPE = 'PROCEDURE'
ORDER BY ROUTINE_SCHEMA, LEN(ROUTINE_DEFINITION) DESC;

-- ============================================================
-- QUERY 4: Full stored procedure definitions
-- Save as: 04-stored-proc-definitions.csv
-- Use this to copy individual procs into Copilot Chat
-- ============================================================
SELECT
    DB_NAME()                   AS Database_Name,
    ROUTINE_SCHEMA,
    ROUTINE_NAME,
    ROUTINE_DEFINITION
FROM INFORMATION_SCHEMA.ROUTINES
WHERE ROUTINE_TYPE = 'PROCEDURE'
ORDER BY ROUTINE_SCHEMA, ROUTINE_NAME;

-- ============================================================
-- QUERY 5: Cross-schema foreign keys — SERVICE BOUNDARY MAP
-- Save as: 05-cross-schema-fkeys.csv
-- These are your highest migration risk — shared tables across domains
-- ============================================================
SELECT
    DB_NAME()                                            AS Database_Name,
    fk.name                                              AS FK_Name,
    OBJECT_SCHEMA_NAME(fk.parent_object_id)              AS From_Schema,
    OBJECT_NAME(fk.parent_object_id)                     AS From_Table,
    COL_NAME(fkc.parent_object_id, fkc.parent_column_id) AS From_Column,
    OBJECT_SCHEMA_NAME(fk.referenced_object_id)          AS To_Schema,
    OBJECT_NAME(fk.referenced_object_id)                 AS To_Table,
    COL_NAME(fkc.referenced_object_id, fkc.referenced_column_id) AS To_Column,
    CASE
        WHEN OBJECT_SCHEMA_NAME(fk.parent_object_id) <>
             OBJECT_SCHEMA_NAME(fk.referenced_object_id)
        THEN 'CROSS-SCHEMA - HIGH RISK'
        ELSE 'Same schema'
    END AS Risk_Flag
FROM sys.foreign_keys fk
JOIN sys.foreign_key_columns fkc
    ON fk.object_id = fkc.constraint_object_id
ORDER BY Risk_Flag DESC, From_Schema, From_Table;

-- ============================================================
-- QUERY 6: Stored proc → table dependency map
-- Save as: 06-proc-table-dependencies.csv
-- Shows which procs touch which tables — drives migration ordering
-- ============================================================
SELECT
    DB_NAME()                         AS Database_Name,
    OBJECT_SCHEMA_NAME(o.object_id)   AS Proc_Schema,
    o.name                            AS Proc_Name,
    d.referenced_schema_name          AS Referenced_Schema,
    d.referenced_entity_name          AS Referenced_Table_Or_View,
    CASE
        WHEN d.is_updated = 1 THEN 'WRITE'
        ELSE 'READ'
    END                               AS Access_Type
FROM sys.objects o
JOIN sys.sql_expression_dependencies d
    ON d.referencing_id = o.object_id
WHERE o.type = 'P'
  AND d.referenced_entity_name IS NOT NULL
ORDER BY Proc_Schema, Proc_Name, Access_Type;

-- ============================================================
-- QUERY 7: Tables with NO foreign keys — easiest to migrate first
-- Save as: 07-standalone-tables.csv
-- ============================================================
SELECT
    DB_NAME()               AS Database_Name,
    t.TABLE_SCHEMA,
    t.TABLE_NAME,
    COUNT(c.COLUMN_NAME)    AS Column_Count,
    'No FK dependencies - safe to migrate early' AS Note
FROM INFORMATION_SCHEMA.TABLES t
JOIN INFORMATION_SCHEMA.COLUMNS c
    ON  t.TABLE_NAME   = c.TABLE_NAME
    AND t.TABLE_SCHEMA = c.TABLE_SCHEMA
WHERE t.TABLE_TYPE = 'BASE TABLE'
  AND NOT EXISTS (
      SELECT 1 FROM sys.foreign_keys fk
      WHERE OBJECT_NAME(fk.parent_object_id) = t.TABLE_NAME
        AND OBJECT_SCHEMA_NAME(fk.parent_object_id) = t.TABLE_SCHEMA
  )
GROUP BY t.TABLE_SCHEMA, t.TABLE_NAME
ORDER BY t.TABLE_SCHEMA, t.TABLE_NAME;

-- ============================================================
-- QUERY 8: Views — often contain hidden business logic
-- Save as: 08-views.csv
-- ============================================================
SELECT
    DB_NAME()           AS Database_Name,
    TABLE_SCHEMA,
    TABLE_NAME          AS View_Name,
    VIEW_DEFINITION
FROM INFORMATION_SCHEMA.VIEWS
ORDER BY TABLE_SCHEMA, TABLE_NAME;

-- ============================================================
-- QUERY 9: Most coupled tables — migrate these last
-- Save as: 09-most-coupled-tables.csv
-- ============================================================
SELECT
    DB_NAME()                                  AS Database_Name,
    OBJECT_SCHEMA_NAME(fk.parent_object_id)    AS Schema_Name,
    OBJECT_NAME(fk.parent_object_id)           AS Table_Name,
    COUNT(*)                                   AS Inbound_FK_Count,
    'High coupling - plan carefully'           AS Recommendation
FROM sys.foreign_keys fk
GROUP BY
    OBJECT_SCHEMA_NAME(fk.parent_object_id),
    OBJECT_NAME(fk.parent_object_id)
ORDER BY Inbound_FK_Count DESC;

-- ============================================================
-- QUERY 10: Index definitions — needed for Databricks schema design
-- Save as: 10-indexes.csv
-- ============================================================
SELECT
    DB_NAME()                   AS Database_Name,
    SCHEMA_NAME(t.schema_id)    AS Schema_Name,
    t.name                      AS Table_Name,
    i.name                      AS Index_Name,
    i.type_desc                 AS Index_Type,
    i.is_unique                 AS Is_Unique,
    i.is_primary_key            AS Is_Primary_Key,
    STRING_AGG(c.name, ', ')
        WITHIN GROUP (ORDER BY ic.key_ordinal)  AS Columns
FROM sys.indexes i
JOIN sys.tables t
    ON i.object_id = t.object_id
JOIN sys.index_columns ic
    ON  i.object_id = ic.object_id
    AND i.index_id  = ic.index_id
JOIN sys.columns c
    ON  ic.object_id  = c.object_id
    AND ic.column_id  = c.column_id
WHERE i.name IS NOT NULL
GROUP BY
    SCHEMA_NAME(t.schema_id),
    t.name,
    i.name,
    i.type_desc,
    i.is_unique,
    i.is_primary_key
ORDER BY Schema_Name, Table_Name, Is_Primary_Key DESC;
