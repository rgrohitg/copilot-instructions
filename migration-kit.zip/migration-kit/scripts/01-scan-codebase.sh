#!/bin/bash
# ============================================================
# 01-scan-codebase.sh
# Run from the ROOT of your .NET solution directory
# Saves all output to docs/migration/ automatically
#
# Usage:
#   bash scripts/01-scan-codebase.sh
#
# This script scans your .NET codebase only.
# For SQL Server metadata, open SSMS and run:
#   scripts/sql/sql-metadata-extraction.sql
# Set USE [YOUR_DATABASE_NAME] at the top of that file.
# ============================================================

set -e

OUTPUT_DIR="docs/migration"
mkdir -p "$OUTPUT_DIR"

echo "========================================"
echo " .NET Codebase Discovery Scanner"
echo " Output: $OUTPUT_DIR"
echo ""
echo " SQL metadata: run sql-metadata-extraction.sql"
echo " in SSMS with your database name set at top."
echo "========================================"


# --------------------------------------------------------
# 1. Full folder tree (all .cs files, grouped by folder)
# --------------------------------------------------------
echo "[1/9] Scanning folder structure..."
{
  echo "# Folder Structure"
  echo "_Generated: $(date)_"
  echo ""
  echo "## All .cs files by directory"
  echo '```'
  find . -type f -name "*.cs" | sed 's|/[^/]*$||' | sort -u
  echo '```'
  echo ""
  echo "## File count per folder (largest first)"
  echo '```'
  find . -name "*.cs" | awk -F/ 'NF>2{print $(NF-1)}' | sort | uniq -c | sort -rn
  echo '```'
} > "$OUTPUT_DIR/02a-folder-structure.md"
echo "    Saved: 02a-folder-structure.md"

# --------------------------------------------------------
# 2. All Controllers
# --------------------------------------------------------
echo "[2/9] Finding all controllers..."
{
  echo "# All Controllers"
  echo "_Generated: $(date)_"
  echo ""
  echo "## Controller file paths"
  echo '```'
  find . -name "*Controller*.cs" | sort
  echo '```'
  echo ""
  echo "## Controller names (extracted)"
  echo '```'
  grep -rn "class.*Controller" --include="*.cs" | grep -v "//" | sort
  echo '```'
} > "$OUTPUT_DIR/02b-controllers.md"
echo "    Saved: 02b-controllers.md"

# --------------------------------------------------------
# 3. All Service classes
# --------------------------------------------------------
echo "[3/9] Finding all service classes..."
{
  echo "# All Service Classes"
  echo "_Generated: $(date)_"
  echo ""
  echo '```'
  find . -name "*Service*.cs" | sort
  echo '```'
  echo ""
  echo "## Service class declarations"
  echo '```'
  grep -rn "class.*Service" --include="*.cs" | grep -v "//" | sort
  echo '```'
} > "$OUTPUT_DIR/02c-services.md"
echo "    Saved: 02c-services.md"

# --------------------------------------------------------
# 4. All Repository / Data Access classes
# --------------------------------------------------------
echo "[4/9] Finding data access layer..."
{
  echo "# Data Access Layer"
  echo "_Generated: $(date)_"
  echo ""
  echo "## Repository / DAL files"
  echo '```'
  find . \( -name "*Repository*.cs" -o -name "*DataAccess*.cs" -o -name "*Dal*.cs" -o -name "*Dao*.cs" \) | sort
  echo '```'
  echo ""
  echo "## Class declarations"
  echo '```'
  grep -rn "class.*\(Repository\|DataAccess\|Dal\|Dao\)" --include="*.cs" | grep -v "//" | sort
  echo '```'
} > "$OUTPUT_DIR/02d-data-access.md"
echo "    Saved: 02d-data-access.md"

# --------------------------------------------------------
# 5. All Stored Procedure call sites
# --------------------------------------------------------
echo "[5/9] Finding all stored procedure call sites..."
{
  echo "# Stored Procedure Call Sites"
  echo "_Generated: $(date)_"
  echo ""
  echo "## Files that call stored procedures"
  echo '```'
  grep -rn "CommandType.StoredProcedure\|StoredProcedure\|ExecuteReader\|ExecuteNonQuery\|ExecuteScalar\|\"usp_\|\"sp_" \
    --include="*.cs" -l | sort
  echo '```'
  echo ""
  echo "## All stored procedure name references"
  echo '```'
  grep -rn "CommandType.StoredProcedure\|\"usp_\|\"sp_\| = \"[a-zA-Z].*proc\|procName\|spName" \
    --include="*.cs" | sort
  echo '```'
} > "$OUTPUT_DIR/02e-stored-proc-callsites.md"
echo "    Saved: 02e-stored-proc-callsites.md"

# --------------------------------------------------------
# 6. External HTTP / API calls
# --------------------------------------------------------
echo "[6/9] Finding external HTTP calls..."
{
  echo "# External HTTP / API Calls"
  echo "_Generated: $(date)_"
  echo ""
  echo "## Files making external calls"
  echo '```'
  grep -rn "HttpClient\|WebClient\|RestClient\|HttpWebRequest\|IRestClient" \
    --include="*.cs" -l | sort
  echo '```'
  echo ""
  echo "## Call details"
  echo '```'
  grep -rn "HttpClient\|WebClient\|RestClient\|HttpWebRequest\|baseUrl\|BaseAddress\|GetAsync\|PostAsync" \
    --include="*.cs" | sort
  echo '```'
} > "$OUTPUT_DIR/02f-external-calls.md"
echo "    Saved: 02f-external-calls.md"

# --------------------------------------------------------
# 7. Config / Connection String references
# --------------------------------------------------------
echo "[7/9] Finding config and connection string references..."
{
  echo "# Config and Connection String References"
  echo "_Generated: $(date)_"
  echo ""
  echo "## Files referencing config"
  echo '```'
  grep -rn "ConfigurationManager\|IConfiguration\|appSettings\|connectionString\|SqlConnection\|IDbConnection" \
    --include="*.cs" -l | sort
  echo '```'
  echo ""
  echo "## Connection string references"
  echo '```'
  grep -rn "connectionString\|SqlConnection\|IDbConnection" \
    --include="*.cs" | sort
  echo '```'
  echo ""
  echo "## appsettings.json / web.config files"
  echo '```'
  find . \( -name "appsettings*.json" -o -name "web.config" -o -name "app.config" \) | sort
  echo '```'
} > "$OUTPUT_DIR/02g-config-references.md"
echo "    Saved: 02g-config-references.md"

# --------------------------------------------------------
# 8. NuGet packages (dependencies)
# --------------------------------------------------------
echo "[8/9] Finding NuGet package dependencies..."
{
  echo "# NuGet Package Dependencies"
  echo "_Generated: $(date)_"
  echo ""
  echo "## All packages.config / .csproj package references"
  echo '```'
  find . \( -name "packages.config" -o -name "*.csproj" \) | sort
  echo '```'
  echo ""
  echo "## Package references extracted"
  echo '```'
  grep -rn "PackageReference\|package id=" \
    --include="*.csproj" --include="packages.config" | sort
  echo '```'
} > "$OUTPUT_DIR/02h-nuget-packages.md"
echo "    Saved: 02h-nuget-packages.md"

# --------------------------------------------------------
# 9. Windows-specific / risky patterns
# --------------------------------------------------------
echo "[9/9] Scanning for high-risk patterns..."
{
  echo "# High Risk Pattern Scan"
  echo "_Generated: $(date)_"
  echo ""
  echo "## Static classes / shared state"
  echo '```'
  grep -rn "static class\|static readonly\|static.*Dictionary\|static.*List" \
    --include="*.cs" | grep -v "//\|test\|Test" | sort
  echo '```'
  echo ""
  echo "## File system access"
  echo '```'
  grep -rn "File\.\|Directory\.\|FileStream\|StreamReader\|StreamWriter\|Path\." \
    --include="*.cs" | grep -v "//\|\.csproj" | sort
  echo '```'
  echo ""
  echo "## Windows-specific APIs"
  echo '```'
  grep -rn "Registry\|COM\|DllImport\|WindowsIdentity\|WindowsPrincipal\|Environment.GetFolderPath" \
    --include="*.cs" | sort
  echo '```'
  echo ""
  echo "## Inline SQL (not stored procs)"
  echo '```'
  grep -rn "SELECT \|INSERT INTO\|UPDATE \|DELETE FROM\|CommandText.*=" \
    --include="*.cs" | grep -v "usp_\|sp_\|//\|StoredProcedure" | sort
  echo '```'
  echo ""
  echo "## Background tasks / scheduled jobs"
  echo '```'
  grep -rn "Timer\|HostedService\|BackgroundService\|IJob\|Quartz\|Hangfire\|Task.Run\|Thread " \
    --include="*.cs" -l | sort
  echo '```'
} > "$OUTPUT_DIR/02i-risk-patterns.md"
echo "    Saved: 02i-risk-patterns.md"

# --------------------------------------------------------
# Summary index
# --------------------------------------------------------
{
  echo "# Codebase Scan Index"
  echo "_Generated: $(date)_"
  echo ""
  echo "Run \`bash scripts/01-scan-codebase.sh\` from solution root to regenerate."
  echo ""
  echo "| File | Contents |"
  echo "|------|----------|"
  echo "| 02a-folder-structure.md | All folders and file counts |"
  echo "| 02b-controllers.md | All HTTP controllers |"
  echo "| 02c-services.md | All service classes |"
  echo "| 02d-data-access.md | Repository and DAL classes |"
  echo "| 02e-stored-proc-callsites.md | Where stored procs are called |"
  echo "| 02f-external-calls.md | External HTTP/API integrations |"
  echo "| 02g-config-references.md | Config and connection strings |"
  echo "| 02h-nuget-packages.md | All NuGet dependencies |"
  echo "| 02i-risk-patterns.md | High risk code patterns |"
  echo ""
  echo "## Next step"
  echo "Run \`scripts/sql/\` queries in SQL Server Management Studio and save outputs to \`docs/migration/02j-database-inventory/\`"
} > "$OUTPUT_DIR/00-scan-index.md"

echo ""
echo "========================================"
echo " Scan complete!"
echo " Open docs/migration/ to review outputs"
echo " Next: run the SQL scripts in scripts/sql/"
echo "========================================"
