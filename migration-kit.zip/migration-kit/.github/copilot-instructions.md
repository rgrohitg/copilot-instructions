# Copilot Project Instructions

> This file is read automatically by GitHub Copilot in every chat session.
> Keep it updated as the migration progresses.
> Last updated: [UPDATE THIS DATE EACH TIME YOU EDIT]

---

## What this project is

A legacy .NET monolith being migrated to:
- **Frontend:** React + TypeScript
- **Services:** Java 17 + Spring Boot 3
- **Data layer:** Databricks (target) — **NOT YET LIVE**
- **Interim data layer:** DuckDB (stand-in during migration)

Migration is **in progress**. The codebase is intentionally inconsistent.
Some modules are already migrated, others are not. Never assume uniformity.

---

## Source stack (the .NET monolith)

- Framework: .NET Framework [FILL IN VERSION]
- Architecture: [FILL IN e.g. MVC / Layered / N-Tier]
- ORM / Data access: [FILL IN e.g. Dapper / raw ADO.NET / Entity Framework]
- Auth: [FILL IN e.g. Windows Auth / Forms Auth / JWT]
- SQL Server with schemas:
  - `[Schema1]` — owns: [FILL IN domain e.g. Customer, Accounts]
  - `[Schema2]` — owns: [FILL IN domain e.g. Orders, Transactions]
  - `[Schema3]` — owns: [FILL IN domain e.g. Reference data, Config]
- Heavy use of stored procedures — business logic lives in SQL, not always in C#

---

## Target stack

- React + TypeScript (frontend, Vite)
- Java 17 + Spring Boot 3 (REST services)
- Databricks (final data platform) — schemas TBD
- DuckDB (temporary — swap out when Databricks is ready)
- [FILL IN any messaging e.g. Kafka / RabbitMQ if applicable]

---

## Migration state — update this as you go

### Already migrated
- [ ] [List completed screens/modules here]

### In progress
- [ ] [Current focus]

### Not started
- Everything not listed above

---

## Database critical rules

- **Never assume a table belongs to one service.** Cross-schema joins exist.
- **DuckDB is temporary.** Write all SQL as ANSI-compatible. No DuckDB-specific syntax.
- **Repository interface pattern is mandatory.** Services must never know whether
  they are talking to DuckDB or Databricks. Always inject a repository interface.
- **Stored procedures encode business logic.** Never skip them when analysing a feature.
  A controller that looks simple may delegate all real logic to a stored proc.

---

## Stored procedure conventions

- Naming pattern: [FILL IN e.g. `usp_SchemaName_ActionVerb`]
- Location: SQL Server database `[FILL IN DB NAME]`
- Documented in: `docs/migration/stored-procs/`
- **Always document a stored proc before migrating the feature that calls it.**

---

## Documentation standard — mandatory before any migration

Every feature must have a **Feature Documentation Card** before migration starts.
Template: `.github/prompts/01-scan-feature.prompt.md`

Every stored procedure must be documented before the feature using it is migrated.
Template: `.github/prompts/02-document-stored-proc.prompt.md`

All docs live in: `docs/migration/`

---

## What NOT to do

- ❌ Do not migrate a feature before its Feature Documentation Card exists
- ❌ Do not embed Databricks-specific SQL — use ANSI SQL only for now
- ❌ Do not put business logic in controllers or repositories — it belongs in services
- ❌ Do not collapse schemas into one service — each schema maps to its own service domain
- ❌ Do not use `static` shared state in Java services
- ❌ Do not suggest Entity Framework patterns — we are on JDBC/JdbcTemplate
- ❌ Do not read the whole codebase at once — work one controller or service at a time

---

## Prompts available (use these by referencing the file)

| Prompt file | Purpose |
|-------------|---------|
| `01-scan-feature.prompt.md` | Document a controller + its feature |
| `02-document-stored-proc.prompt.md` | Document a stored procedure |
| `03-risk-scan.prompt.md` | Risk-only scan of any file |
| `04-migrate-controller.prompt.md` | Generate Java service from doc card |
| `05-solution-overview.prompt.md` | One-time full project overview |
| `06-controller-inventory.prompt.md` | List all controllers and their routes |
| `07-dependency-scan.prompt.md` | Find all external integrations |
| `08-unknown-unknowns.prompt.md` | Ask Copilot what it thinks you're missing |

---

## Folder structure for docs

```
docs/
└── migration/
    ├── 00-scan-index.md
    ├── 01-project-overview.md
    ├── 02a-folder-structure.md
    ├── 02b-controllers.md
    ...
    ├── 02j-database-inventory/    ← SQL Server CSV exports go here
    ├── features/                  ← One .md per feature
    └── stored-procs/              ← One .md per stored procedure
```
