# Prompt: Controller Inventory (Run Once)

> **How to use:**
> Use `@workspace` in Copilot Chat.
> Run after the solution overview, before per-controller deep scans.
> Save output to `docs/migration/02b-controllers.md`

---

@workspace

List every HTTP controller in this .NET solution.

**Do NOT document implementations yet. Only map the surface API contract.**

For each controller produce this output:

---

### [ControllerName]

**File:** [path/to/file.cs]  
**Namespace:** [namespace]  
**Base route:** [route prefix if defined]  
**Inherits from:** [base class]  
**Constructor dependencies:** [list injected services]  

**Action methods:**

| Method Name | HTTP Verb | Route | Auth Required | Brief Description |
|-------------|-----------|-------|---------------|-------------------|
| MethodName | GET/POST/PUT/DELETE | /route/{id} | Yes/No/Role | one line |

---

After listing all controllers, produce:

## Summary Statistics

- Total controllers: [n]
- Total action methods: [n]
- Controllers with auth: [n]
- Controllers with direct DB access (no service layer): [n] — list them
- Largest controllers by method count: top 5

## Migration Order Recommendation

Based on dependency and complexity, suggest a migration order:

| Priority | Controller | Reason |
|----------|------------|--------|
| 1 | [name] | [why start here — low risk, foundational, etc.] |
| 2 | [name] | [reason] |
...

Flag any controllers that should be migrated LAST due to complexity.
