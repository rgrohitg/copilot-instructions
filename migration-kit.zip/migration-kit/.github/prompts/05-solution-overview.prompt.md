# Prompt: Solution Overview (Run Once)

> **How to use:** 
> Run this ONCE at the very start before any other scanning.
> Use `@workspace` in Copilot Chat — this needs the full workspace index.
> Save output to `docs/migration/01-project-overview.md`

---

@workspace

I am documenting this .NET application before migrating it to a modern stack.

**Do NOT suggest any migration yet. Do NOT write any new code.
Only document what currently exists.**

Produce a complete project overview covering:

---

## 1. Application Purpose
What does this application do? Who uses it? What business domain does it serve?
Write this in plain English as if explaining to a new team member on day one.

---

## 2. Main Functional Areas
What are the major feature areas or modules in this application?
List them with a one-sentence description of each.

---

## 3. Project / Solution Structure
How is the solution organised?
- What projects exist in the solution?
- What is the responsibility of each project?
- What is the dependency order between projects?

---

## 4. Architectural Pattern
What pattern does this application follow?
(e.g. MVC, Layered / N-Tier, CQRS, Clean Architecture, Big Ball of Mud)
Be honest — describe what it actually is, not what it was intended to be.

---

## 5. Data Access Approach
- What ORM or data access technology is used? (EF, Dapper, raw ADO.NET)
- Is there a clear repository pattern, or is DB access scattered?
- Roughly how much logic lives in stored procedures vs C# code?

---

## 6. Authentication and Authorisation
- What auth mechanism is used? (Windows Auth, Forms, JWT, OAuth)
- Is authorisation role-based, policy-based, or ad hoc?
- Where does session management happen?

---

## 7. Cross-Cutting Concerns
How are these handled — and are they consistent?
- Logging (what framework, where is it used)
- Error handling (global handler, per-controller, inconsistent)
- Validation (data annotations, FluentValidation, manual)
- Caching (what is cached, how)
- Configuration management

---

## 8. External Integrations
What does this application talk to besides its own database?
List every external system, API, or service you can identify.

---

## 9. Unusual or Legacy Patterns
What looks old, hacky, or non-standard?
What would a new developer find most surprising or confusing?
Be direct — these are the migration risks.

---

## 10. Overall Migration Complexity Assessment
Given everything above, what is your honest assessment of:
- How large is this migration? (Small / Medium / Large / Very Large)
- What are the top 3 things that will make this hard?
- What is surprisingly simple or well-structured that works in our favour?
