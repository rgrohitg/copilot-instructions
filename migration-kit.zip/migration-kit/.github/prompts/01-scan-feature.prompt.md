# Prompt: Scan and Document a Feature

> **How to use:** Open the controller file in VS Code. Open Copilot Chat.
> Type: `Use #01-scan-feature.prompt.md on this controller`
> Save the output to `docs/migration/features/[FeatureName].md`

---

I am documenting this .NET controller and its associated feature for migration 
planning purposes. 

**Do NOT write any migration code. Do NOT suggest React or Java implementations.
Only document what currently exists.**

Analyse the open file and produce a Feature Documentation Card using exactly 
this format:

---

## Feature: [Name — infer from controller name]

**Controller:** [ClassName]  
**File:** [filename]  
**Base Route:** [if defined]  

---

### 1. Purpose
What does this controller do in plain English? One short paragraph.

---

### 2. Action Methods

For each public action method:

#### [MethodName] — [HTTP Verb] [route]
- **Input:** [query params, route params, request body — list each with type]
- **Auth/Permission check:** [any [Authorize] attributes or manual checks]
- **Step-by-step logic:** [numbered list of what it does]
- **Returns:** [what response / view / redirect]
- **Error paths:** [what happens if something fails]

---

### 3. Service Dependencies
List every service class or interface this controller injects or calls.
For each: name, and what it is used for in this controller.

---

### 4. Database Access
Does this controller access the DB directly, or only through services?

**Tables referenced (directly or via service calls):**
| Schema | Table | Read/Write | How (direct / via service / via stored proc) |
|--------|-------|------------|----------------------------------------------|

**Stored procedures called (list names only — do not expand them yet):**
- [proc name]

---

### 5. Business Rules Visible at Controller Level
List every validation rule, calculation, or conditional business decision
that lives in the controller code itself (not delegated to a service).

---

### 6. External Dependencies
- External APIs called: [list with URL if visible]
- File system access: [yes/no — describe]
- Email: [yes/no — describe]
- Queues / events: [yes/no — describe]
- Session / cookie state: [yes/no — describe]

---

### 7. Config Dependencies
List any appsettings keys, environment variables, or feature flags this 
controller or its immediate dependencies reference.

---

### 8. Migration Risk Assessment

**Rating:** 🟢 Low / 🟡 Medium / 🔴 High

**Reason:** [one sentence]

**Specific risks:**
- [list each concern]

---

### 9. Open Questions
Things that need investigation before migration can start:
- [list]

---

### 10. Suggested Java Service Name
Based on the responsibility of this controller, suggest:
- **Java Controller class:** 
- **Java Service class:** 
- **Java Repository interface:** 
