# Prompt: External Dependency and Integration Scan

> **How to use:**
> Use `@workspace` in Copilot Chat.
> Run this once early in the discovery phase.
> Save output to `docs/migration/03-dependency-map.md`

---

@workspace

Scan this entire codebase for external integrations and dependencies.

**Do NOT suggest migration. Only document what exists and the risk each poses.**

---

## 1. External HTTP / REST API Calls
Find every place this application calls an external HTTP endpoint.

For each:
- Class and method where the call is made
- Target URL or base address (if visible in code or config)
- HTTP method used
- What data is sent / received
- Is there error handling / retry logic?
- **Migration risk:** What needs to happen before this can work in Java?

---

## 2. Database Connections
Find every distinct database connection in the codebase.

For each:
- Connection string name / key
- Where it is used (which classes/layers)
- Which schema(s) it accesses
- Is connection management handled consistently?

---

## 3. Email Sending
Is email sent anywhere in this application?

For each email:
- What triggers it
- What library is used (SmtpClient, SendGrid, etc.)
- Template / body approach (inline, template file, third-party)
- **Migration note:** What config changes when moving to cloud/Java?

---

## 4. File System Access
Find every file read or write operation.

For each:
- What is being read/written
- Hard-coded path vs config-driven
- Windows path conventions used? (backslashes, drive letters)
- **Migration risk:** Paths and file access work differently in Linux/cloud

---

## 5. Message Queues / Event Bus
Is there any async messaging? (RabbitMQ, Azure Service Bus, MSMQ, Kafka, etc.)

For each:
- Queue or topic name
- What is published
- What is consumed
- **Migration note:** Broker config and client library both change

---

## 6. Scheduled Jobs / Background Tasks
Any scheduled execution or background processing?

For each:
- What runs on a schedule
- How is it scheduled (Quartz, Hangfire, Windows Task Scheduler, Timer)
- How often
- **Migration approach:** Will need Spring @Scheduled or separate job service

---

## 7. Authentication / Identity Providers
External auth integrations (Azure AD, LDAP, OAuth providers)?

For each:
- Provider name
- How the token/identity is consumed in code
- **Migration note:** Azure AD B2C / OAuth2 config differs in Spring Boot

---

## 8. Third-party NuGet Packages — No Java Equivalent

List every NuGet package that:
- Has no direct Java/Maven equivalent
- Does something Windows-specific
- Is a major concern for migration

| Package | Version | What it does | Java alternative or approach |
|---------|---------|--------------|------------------------------|

---

## 9. Dependency Injection Setup
- What DI container is used? (built-in .NET DI, Autofac, Ninject, etc.)
- Are there any unusual registrations (factories, decorators, keyed services)?
- **Migration note:** Spring Boot DI works differently — flag complex registrations

---

## 10. Integration Risk Summary

| Integration | Complexity | Blocking? | Action needed before Java migration |
|-------------|------------|-----------|--------------------------------------|
| [name] | Low/Med/High | Yes/No | [what to do] |
