# Prompt: Document a Stored Procedure

> **How to use:** 
> 1. Find the stored procedure in SQL Server Management Studio
> 2. Right-click → Script as → CREATE to → New Query Window
> 3. Copy the full SQL text
> 4. Open Copilot Chat in VS Code
> 5. Paste the SQL directly into the chat with this prompt above it
> 6. Save output to `docs/migration/stored-procs/[ProcName].md`
>
> ⚠️ Do NOT reference the .sql file — paste directly. Avoids timeout issues.

---

I am documenting a SQL Server stored procedure that contains business logic 
which must be migrated into a Java Spring Boot service layer.

**Do NOT write any Java code yet. Only document what this procedure does.**

Here is the stored procedure:

[PASTE THE STORED PROCEDURE SQL HERE]

Document it using exactly this format:

---

## Stored Procedure: [name]

**Schema:** [schema]  
**Estimated complexity:** 🟢 Low / 🟡 Medium / 🔴 High  
**Last altered:** [if visible in the SQL]  

---

### 1. Purpose
What does this stored procedure do in plain English? One paragraph.

---

### 2. Parameters

| Parameter | Data Type | Direction | Purpose |
|-----------|-----------|-----------|---------|
| @ParamName | type | IN / OUT / IN-OUT | what it means |

---

### 3. Tables Accessed

| Schema.Table | Operation | Condition / Filter | Notes |
|-------------|-----------|-------------------|-------|
| schema.TableName | READ / INSERT / UPDATE / DELETE | WHERE clause summary | any notes |

---

### 4. Business Logic — Plain English

Extract every business rule step by step. Do not paraphrase SQL — explain 
what the logic *means* in business terms.

1. [step]
2. [step]
...

---

### 5. Calculations and Derived Values

List every calculated field, formula, or derived value:
- **[Field name]:** [what it calculates and why]

---

### 6. Conditional Branches

Describe every IF/CASE/WHEN branch:
- **Condition:** [what triggers it]
- **Then:** [what happens]
- **Else:** [what happens otherwise]

---

### 7. Error Handling

- TRY/CATCH present: Yes / No
- RAISERROR / THROW used: Yes / No — [describe conditions]
- Transaction rollback: Yes / No — [describe when]
- What the calling code receives on error: [describe]

---

### 8. High Risk Patterns

- **Cursors / loops:** Yes / No — [if yes: describe what they iterate and why]
- **Dynamic SQL:** Yes / No — [if yes: describe what is dynamic and why]
- **Temp tables:** Yes / No — [if yes: describe]
- **Cross-schema access:** Yes / No — [list schemas touched]
- **Multiple result sets:** Yes / No

---

### 9. Migration Notes

**Proposed Java service class:** [e.g. PaymentService]  
**Proposed method name:** [e.g. processPayment()]  
**Repository calls needed:**
- [e.g. paymentRepository.findById()]
- [e.g. auditRepository.save()]

**Migration risk:** 🟢 Low / 🟡 Medium / 🔴 High  
**Risk reason:** [one sentence]

**Open questions before migration:**
- [list]
