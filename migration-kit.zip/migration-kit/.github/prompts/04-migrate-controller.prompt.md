# Prompt: Migrate .NET Controller to Java Spring Boot

> **How to use:** 
> 1. Confirm the Feature Documentation Card exists in `docs/migration/features/`
> 2. Confirm all stored procs it calls are documented in `docs/migration/stored-procs/`
> 3. Open Copilot Chat and paste the Feature Documentation Card content
> 4. Run this prompt referencing the doc — NOT the raw .NET code
>
> ⚠️ Pre-conditions — confirm ALL before proceeding:
> - [ ] Feature Documentation Card is complete
> - [ ] All stored procedures called have been documented  
> - [ ] Data ownership (which service domain owns each table) is confirmed
> - [ ] DuckDB-compatible SQL is acceptable (Databricks not yet live)
> - [ ] Repository interface pattern agreed for this service

---

I am migrating a documented .NET feature to Java Spring Boot.

**Use the Feature Documentation Card as your source of truth.
Do NOT look at the original .NET code — the card is the spec.**

Here is the Feature Documentation Card:

[PASTE FEATURE DOCUMENTATION CARD HERE]

And here are the relevant stored procedure documents:

[PASTE STORED PROC DOCS HERE]

Generate the following, in this order:

---

## 1. DTO / Model Classes

Generate Java record or POJO classes for:
- Request body (if POST/PUT)
- Response body
- Any internal domain objects

Use Java records where immutable, plain classes where mutable.
Include validation annotations (`@NotNull`, `@NotBlank`, etc.) based on 
the business rules in the documentation card.

---

## 2. Repository Interface

Generate a Spring Data / JdbcTemplate repository interface.
- One interface per domain table group
- Method names should reflect business intent, not SQL operations
- Use `@Repository` annotation
- Include method signatures only at this stage (no implementation yet)
- All SQL must be **ANSI-compatible** (no Databricks-specific syntax)
- DuckDB will be the runtime for now — do not use SQL Server-specific functions

---

## 3. Repository Implementation

Generate the JdbcTemplate implementation of the repository interface.
- Use `NamedParameterJdbcTemplate`
- Map result sets using `RowMapper` or `BeanPropertyRowMapper`
- For any business logic that was in a stored procedure, implement it here
  as Java code (NOT as a stored procedure call — we are moving logic to Java)
- Include proper exception handling

---

## 4. Service Class

Generate the `@Service` class.
- All business rules from the documentation card must be implemented here
- Validation logic belongs here, not in the controller
- Inject the repository interface (not the implementation)
- Use constructor injection (not @Autowired field injection)
- Handle errors by throwing specific exception types (create them if needed)

---

## 5. REST Controller

Generate the `@RestController`.
- Match the HTTP verbs and routes from the documentation card exactly
- Controller must be thin — delegate all logic to the service
- Use `@Valid` for request body validation
- Return `ResponseEntity<>` with appropriate HTTP status codes
- Include `@Operation` Swagger annotations

---

## 6. Exception Classes (if needed)

Generate any custom exception classes referenced in the service.

---

## 7. JUnit Test Skeleton

Generate a `@SpringBootTest` or `@WebMvcTest` test class with:
- Happy path test for each endpoint
- Validation failure tests
- One edge case test per business rule listed in the documentation card
- Mockito mocks for the service layer
- Use `@DisplayName` with plain English descriptions

---

## Output notes
- Package structure: `com.[company].[domain].[layer]` — fill in what fits
- Do not include `import` statements — those can be resolved by the IDE
- Flag any business rule from the documentation card that you were 
  uncertain how to implement
