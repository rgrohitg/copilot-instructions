# Prompt: Risk Assessment Scan

> **How to use:** Open a file in VS Code. Open Copilot Chat.
> Type: `Use #03-risk-scan.prompt.md on this file`
> Use this early — before deep documentation — to triage what needs attention.
> Save outputs to `docs/migration/04-risk-register.md` (append, don't overwrite)

---

Scan the provided file or module and identify migration risks only.

**Do NOT generate migration code. Do NOT produce documentation cards.
Only produce a risk register.**

Scan for every item in this checklist:

---

## Risk Checklist

### Database risks
- Cross-schema database access (joins or references across schema boundaries)
- Stored procedure calls with complex or many parameters
- Inline SQL strings embedded in C# code
- Direct SqlConnection / ADO.NET usage (not via repository pattern)
- Transactions managed manually in C# code

### Code architecture risks
- Shared mutable static state (static fields, static dictionaries, singleton abuse)
- God classes (one class doing too many unrelated things)
- Circular dependencies between services
- Business logic in controllers (should be in service layer)
- Business logic in repositories (should be in service layer)

### External dependency risks
- External HTTP/API calls (need contract definition before migration)
- File system access (path conventions change between Windows and Linux/cloud)
- Email sending (SMTP config changes)
- Message queues or event publishing
- Scheduled jobs or background threads

### Windows-specific risks
- Windows Registry access
- COM interop / DllImport
- Windows Authentication / Active Directory
- Windows file path conventions (backslash, drive letters)
- Windows-specific environment variables

### Dependency risks
- Third-party NuGet packages with no Java equivalent
- Very old packages that are no longer maintained
- Packages that wrap Windows-only native libraries

### Configuration risks
- Hardcoded connection strings
- Hardcoded file paths or URLs
- Environment-specific logic baked into code (if prod / if dev)

---

## Output Format

### Risk Register: [File/Module Name]

| # | Risk Description | Location (line/method) | Severity | Migration Impact | Action Required |
|---|-----------------|----------------------|----------|-----------------|-----------------|
| 1 | [describe risk] | [where in code] | 🔴 High / 🟡 Medium / 🟢 Low | [what breaks if ignored] | [what to do about it] |

---

### Summary
**Total risks found:** [n]  
**High severity:** [n]  
**Biggest concern:** [one sentence — the single thing most likely to cause problems]  
**Recommended action before migrating this file:** [one sentence]
