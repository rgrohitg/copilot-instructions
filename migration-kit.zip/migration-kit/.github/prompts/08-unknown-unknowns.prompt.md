# Prompt: Unknown Unknowns Scan

> **How to use:**
> Run this LAST — after all other scans are done.
> Use `@workspace` so Copilot has seen as much of the codebase as possible.
> Save output to `docs/migration/04-risk-register.md`
> 
> This prompt asks Copilot to be honest about what it suspects you don't know yet.
> Read the output carefully — it is often the most valuable document you produce.

---

@workspace

You have now indexed this codebase. I want your honest assessment of the 
migration risk — not the sanitised version.

**Do NOT write migration code. Do NOT suggest solutions yet.
Just tell me what I probably don't know, and what is going to hurt.**

Answer each section directly and specifically. Generic answers are useless here.

---

## 1. What looks like a quick fix that became permanent?
Find code that was clearly added as a workaround and never cleaned up.
For each: where is it, what does it do, and why does it matter for migration?

---

## 2. Where is the most hidden complexity?
What parts of the codebase look simple from the outside but are actually doing 
something subtle or important that is easy to miss?

---

## 3. Where is the migration most likely to break silently?
Not crash — silently produce wrong results. What business logic is subtle enough 
that a rewrite could change the behaviour without anyone immediately noticing?

---

## 4. What looks like a workaround for a database or infrastructure limitation?
Patterns that suggest the original developers were working around something — 
e.g. manual retry loops, polling instead of events, caching things that 
shouldn't need caching, unusual transaction handling.

---

## 5. What has never been tested properly?
What looks like it has no tests, has tests that don't cover the real logic, 
or has logic so tangled that it was probably never fully verified?

---

## 6. What external behaviour does this system depend on that isn't obvious?
Timing assumptions, ordering assumptions, side effects of stored procedures, 
data that is assumed to be clean but probably isn't always?

---

## 7. What would you want to fully understand before agreeing to migrate this?
If you were a senior engineer being asked to sign off on this migration plan, 
what would you refuse to proceed without knowing first?

---

## 8. Confidence rating per major module

For each major controller or feature area you have seen, rate your confidence 
that you have understood it fully:

| Module / Controller | Confidence | What is unclear |
|--------------------|------------|-----------------|
| [name] | 🟢 High / 🟡 Medium / 🔴 Low | [what you don't understand] |

---

## 9. Your honest overall risk rating

**Overall migration risk:** 🟢 Low / 🟡 Medium / 🔴 High / 🚨 Very High

**Top 3 things most likely to cause the migration to go over time/budget:**
1. 
2. 
3. 

**One thing that is better structured than expected:**

**One thing that is worse than it looks:**
